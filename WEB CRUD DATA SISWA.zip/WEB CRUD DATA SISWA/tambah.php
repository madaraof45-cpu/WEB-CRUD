<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Data Siswa</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #dbeafe, #f0f4ff); /* sama seperti dashboard */
            font-family: "Poppins", sans-serif;
            padding: 40px 20px;
        }

        .form-wrapper {
            max-width: 1200px;
            width: 100%;
            margin: auto;
            background: white;
            padding: 40px;
            border-radius: 18px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            border: 1px solid #e5e7eb;
        }

        h3 {
            font-weight: 700;
            font-size: 28px;
            background: linear-gradient(90deg, #4f46e5, #6366f1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 25px;
        }

        label {
            font-weight: 600;
            margin-top: 10px;
        }

        .form-control, select, textarea {
            border-radius: 10px;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6366f1, #4f46e5);
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 500;
            color: white;
            box-shadow: 0 4px 12px rgba(99,102,241,0.5);
        }

        .btn-primary:hover {
            opacity: 0.9;
        }

        .btn-secondary {
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 500;
            background: #9ca3af;
            border: none;
            color: white;
        }

        .btn-secondary:hover {
            background: #6b7280;
        }
    </style>
</head>

<body>

<div class="form-wrapper">

    <h3>Tambah Data Siswa</h3>

    <form method="post">

        <div class="mb-3">
            <label>NIS</label>
            <input type="number" name="nis" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Kelas</label>
            <input type="text" name="kelas" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Jurusan</label>
            <select name="jurusan" class="form-control">
                <option>Teknik komputer dan jaringan</option>
                <option>Pengembangan Perangkat Lunak dan GIM</option>
                <option>Desain Komunikasi Visual</option>
                <option>Bisnis Digital</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat" class="form-control" rows="2"></textarea>
        </div>

        <div class="mb-3">
            <label>No HP</label>
            <input type="text" name="no_hp" class="form-control">
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control">
        </div>

        <div class="mb-3">
            <label>Cita-cita</label>
            <input type="text" name="cita_cita" class="form-control">
        </div>

        <div class="d-flex justify-content-between mt-4">
            <button class="btn btn-primary" name="simpan">Simpan</button>
            <a href="index.php" class="btn btn-secondary">Kembali</a>
        </div>

    </form>

    <?php
    if(isset($_POST['simpan'])){
        mysqli_query($koneksi, "INSERT INTO siswa SET
            nis='$_POST[nis]',
            nama='$_POST[nama]',
            kelas='$_POST[kelas]',
            jurusan='$_POST[jurusan]',
            alamat='$_POST[alamat]',
            no_hp='$_POST[no_hp]',
            email='$_POST[email]',
            cita_cita='$_POST[cita_cita]'
        ");

        echo "<script>alert('Data berhasil ditambah');window.location='index.php'</script>";
    }
    ?>

</div>

</body>
</html>
