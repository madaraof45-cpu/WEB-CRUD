<?php
include "db.php";

$nis = $_GET['nis'];
mysqli_query($koneksi, "DELETE FROM siswa WHERE nis='$nis'");

echo "<script>alert('Data berhasil dihapus');window.location='index.php'</script>";
?>