<?php include "db.php"; ?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Data Siswa</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <style>
        body {
            background: #eef2ff;
            font-family: 'Poppins', sans-serif;
        }
        .header {
            background: #2563eb;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 26px;
            font-weight: 600;
            margin-bottom: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .card-custom {
            background: white;
            padding: 25px;
            border-radius: 18px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        }
        thead {
            background: #2563eb;
            color: white;
        }
        tbody tr:hover {
            background: #e0e7ff;
        }
    </style><style>
    body {
        background: linear-gradient(135deg, #dbeafe, #f0f4ff);
        font-family: 'Poppins', sans-serif;
    }

    .header {
        background: linear-gradient(90deg, #4f46e5, #6366f1);
        color: white;
        padding: 22px;
        text-align: center;
        font-size: 28px;
        font-weight: 600;
        border-bottom-left-radius: 25px;
        border-bottom-right-radius: 25px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .card-custom {
        background: white;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 12px 25px rgba(0,0,0,0.08);
        border: 1px solid #e5e7eb;
    }

    .btn-primary {
        background: linear-gradient(90deg, #6366f1, #4f46e5);
        border: none;
        border-radius: 10px;
        padding: 10px 18px;
        font-weight: 500;
        box-shadow: 0 4px 14px rgba(99,102,241,0.5);
        transition: 0.2s ease;
    }
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 7px 18px rgba(99,102,241,0.7);
    }

    thead {
        background: linear-gradient(90deg, #4f46e5, #6366f1);
        color: white;
    }

    tbody tr {
        transition: 0.25s;
    }
    tbody tr:hover {
        background: #eef2ff;
        transform: scale(1.01);
        box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    }

    table {
        border-radius: 12px !important;
        overflow: hidden;
    }

    .btn-warning {
        border-radius: 8px;
        font-weight: 500;
        background: #fbbf24;
        border: none;
    }

    .btn-danger {
        border-radius: 8px;
        font-weight: 500;
        background: #ef4444;
        border: none;
    }

    .btn-warning:hover {
        background: #f59e0b;
    }
    .btn-danger:hover {
        background: #dc2626;
    }
</style>
</head>

<body>

<div class="header">Data Siswa</div>

<div class="container">

    <div class="card-custom">

        <a href="tambah.php" class="btn btn-primary mb-3">Tambah Data</a>

        <table class="table table-hover align-middle">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Jurusan</th>
                    <th>No HP</th>
                    <th>Email</th>
                    <th>Cita - cita</th>
                    <th style="width: 150px;">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php
                $no = 1;
                $data = mysqli_query($koneksi, "SELECT * FROM siswa ORDER BY nis DESC");
                while($d = mysqli_fetch_assoc($data)){
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $d['nis'] ?></td>
                    <td><?= $d['nama'] ?></td>
                    <td><?= $d['kelas'] ?></td>
                    <td><?= $d['jurusan'] ?></td>
                    <td><?= $d['no_hp'] ?></td>
                    <td><?= $d['email'] ?></td>
                    <td><?= $d['cita_cita'] ?></td>
                    <td>
                        <a href="edit.php?nis=<?= $d['nis']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="hapus.php?nis=<?= $d['nis']; ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Hapus data ini?')">Hapus</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>

    </div>
</div>

</body>
</html>